This file is used as a sample file for the "Fast Writer" software.
Version: alpha 0.1
Date: 2023 01 24